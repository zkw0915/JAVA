package com.huawei.classroom.student.h15;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

public class PrimeUtil {
    LinkedList<Long> lst = null;
    LinkedHashSet st= null;
    public PrimeUtil(){}

    public List<Long> getPrimeList(long start, long end, int threadCount) {
//        System.out.println("start: "+start +" end "+end);
        lst = new LinkedList<>();
        st = new LinkedHashSet<>();
        long length = end-start;

        double perThread = length/((double)threadCount);
//        System.out.println("length "+length + " "+ "count "+perThread);
        Thread ths[] = new Thread[threadCount];
        Timer ts[] = new Timer[threadCount];
        for(int i = 0; i < threadCount; i++){
            ts[i] = new Timer(start + i * perThread, start + (i+1)*perThread > end? end : start+(i+1)*perThread );
            ths[i] = new Thread(ts[i]);
            ths[i].start();
        }
        for(int i = 0; i < threadCount; i++){
            try{
                ths[i].join();
                LinkedHashSet s = ts[i].returnSet();
//                System.out.println("s: "+s);
                st.addAll(s);
            }catch(Exception e){
            }

        }
        lst.addAll(st);
        return lst;
    }

}
