package com.huawei.classroom.student.h15;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class Timer implements Runnable{
    private double start;
    private double end;
    private LinkedHashSet st = null;

    public boolean judge(long x){
        for(long i = 2; i <= Math.sqrt(x) ; i++){
            if(x % i == 0) return false;
        }
        return true;
    }

    public Timer(double start, double end){
        this.start = start;
        this.end = end;
//        System.out.println("start: "+start +" end "+end);
    }

    public LinkedHashSet returnSet(){
        return st;
    }

    @Override
    public void run() {
        st = new LinkedHashSet();
        for(long num = (long)start ; num <= (long)end; num++){
            if(judge(num)){
                st.add(num);
            }
        }

    }
}
