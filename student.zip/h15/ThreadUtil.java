package com.huawei.classroom.student.h15;

public class ThreadUtil extends Thread{
    StringBuffer buff = null;
    public ThreadUtil(StringBuffer buf){
        buff = buf;
    }

    @Override
    public void run() {
//        for(int i = 0; i < 99999; i++);
        try{
            sleep(500);
        }
        catch (Exception e){

        }
        buff.append("ok");
    }
}
