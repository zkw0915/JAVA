package com.huawei.classroom.student.h20;

public interface C extends B{
}
