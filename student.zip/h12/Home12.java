package com.huawei.classroom.student.h12;

import java.util.*;

public class Home12 {

	public Home12() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * 字符串content是一个超市的历次购物小票的合计，每次购物的明细之间用分号分割，每个商品之间用半角逗号分开
	 * 请找出   哪n(n>=1)个商品被同时购买的频率最高，将这n个商品名称的集合（set)返回 
	 * 
	 * @param content，历次购物的明细，例如：炸鸡,可乐,啤酒;薯片,啤酒,炸鸡;啤酒,雪碧,炸鸡
	 * @param n
	 * @return 哪n个商品被同时购买的频率最高，将这n个商品名称的集合（set)返回 
	 *  不会出现并列的情况
	 */
	public Set<String> getFrequentItem(String content,int n)  {
		String[] contents;
		List<String> items;//一次购物的商品列表，每个元素对应一个商品
		Set<String> nItemsAns;
		Map<Set<String>,Integer> nItemsMap;
		Set<Set<String>> nItemsSet;
		int count,max;

		contents=content.split(";");//分出每次的购买明细
		nItemsMap=new HashMap<>();
		for(int i=0;i<contents.length;i++){
			items=Arrays.asList(contents[i].split(","));//对于一次购物，得到商品列表

			//System.out.println(items);
			Set<Set<String>> nIems=new HashSet<>(getNItems(items,new ArrayList<>(),n));
			//System.out.println(nIems);

			for(Set<String> nItem:nIems){
				count=nItemsMap.getOrDefault(nItem,0);
				nItemsMap.put(nItem,count+1);
			}
		}
		    //System.out.println(nItemsMap);
		max=0;
		nItemsAns=new HashSet<>(n);
		nItemsSet=nItemsMap.keySet();
		    //System.out.println(nItemsSet);
		for(Set<String> nItem:nItemsSet){
			if(max<nItemsMap.get(nItem)){
				max=nItemsMap.get(nItem);
				nItemsAns=nItem;
			}
		}
		return nItemsAns;


	}

	public Set<Set<String>> getNItems(List<String> remainItems, List<String> collectItems, int count){//三个参数，剩余元素，取出元素，尚需取出的数量
		Set<Set<String>> result=new HashSet<>();//用于存放结果
		if(count==1){
			for(String remainItem:remainItems){
				Set<String> collectionItemsSet=new HashSet<>(collectItems);
				collectionItemsSet.add(remainItem);
				result.add(collectionItemsSet);
			}
			return result;
		}


		count--;
		for(int i=0;i<remainItems.size();i++){
			List<String> tempremainItems=new ArrayList<>(remainItems);//剩余元素
			List<String> tempcollectItems=new ArrayList<>(collectItems);//取出元素
			tempcollectItems.add(tempremainItems.remove(i));
			result.addAll(getNItems(tempremainItems,tempcollectItems,count));
		}
		return result;

	}
	 
}
