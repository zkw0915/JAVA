package com.huawei.classroom.student.h16;

public class MyServer {
    private int port;

    public void startListen(int port) {
        this.port=port;
    }
}
