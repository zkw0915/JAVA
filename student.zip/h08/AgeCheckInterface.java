package com.huawei.classroom.student.h08;

public interface AgeCheckInterface {
    public void checkAge(int i) throws RuntimeException;
}
