package com.huawei.classroom.student.h08;

public class InvalidUserExcetpion extends Throwable {
    public  InvalidUserExcetpion(){

    }
}
