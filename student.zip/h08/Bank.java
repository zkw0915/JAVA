package com.huawei.classroom.student.h08;

public class Bank {
    private int cash;
    public Bank(){
        cash=0;
    }
    public void save(int i) {
        cash+=i;
    }

    public void get(int i) throws NoMoneyException{
        if(cash>=i)
            cash-=i;
        else
            throw new NoMoneyException();
    }
}
