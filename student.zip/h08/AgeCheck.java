package com.huawei.classroom.student.h08;

public class AgeCheck implements AgeCheckInterface {
    public AgeCheck(){

    }
    public void checkAge(int i) throws RuntimeException{
        if(i>=0&&i<=200)
            return;
        throw new RuntimeException();
    }
}
