package com.huawei.classroom.student.h08;

public class LoginUtil {
    public LoginUtil(){

    }
    public void login(String user_name,String pass_word) throws InvalidUserExcetpion{
        if(user_name.equals("a")&&pass_word.equals("a"))
            return;
        throw new InvalidUserExcetpion();
    }
}
