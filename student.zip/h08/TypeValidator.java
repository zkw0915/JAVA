package com.huawei.classroom.student.h08;

public class TypeValidator {
    public TypeValidator(){

    }
    public void validate(Object abc) throws RuntimeException{
        if(abc instanceof String)
            return;
        throw new RuntimeException();
    }
}
