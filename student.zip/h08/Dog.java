package com.huawei.classroom.student.h08;

public class Dog {
    private int count;//记录投喂次数
    String e="I can not eat more!";

    public Dog(){
        count=0;

    }
    public void feed() throws Exception{
        if(count<3)
            count++;
        else
            throw new Exception(e);

    }

}
