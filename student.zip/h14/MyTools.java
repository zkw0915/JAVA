package com.huawei.classroom.student.h14;

import java.io.*;
import java.util.*;

/**
 * 在本包下增加合适的类和方法， 本程序不但要测试通过，还需要写适当的注释
 * 
 * 不要引用jdk1.8以外第三方的包
 * 
 * @author cjy
 *
 */
public class MyTools {
	public static int CHUNK_SIZE = 4096;


	public MyTools( ) {
		// TODO Auto-generated constructor stub
	}

	//读取txt文件，按\t分隔
	public List<String[]> getNameList(String filename)throws IOException{
		String line="";
		Reader reader;
		List<String[]> result=new ArrayList<>();
		reader=new FileReader(filename);
		LineNumberReader lineReader=new LineNumberReader(reader);//LineNumberReader是读取一行
		while (true){
			line=lineReader.readLine();
			if(line==null)
				break;
			result.add(line.split("\t"));
		}
		return result;
	}

	//取文件名
	public List<String> getValidFileIdList(String filename) throws FileNotFoundException{
		List<String> result=new ArrayList<>();
		File file=new File(filename);
		File[] filelist=file.listFiles();
		if(filelist==null){
			throw  new FileNotFoundException();
		}
		for(File fileEle:filelist){
			String name=fileEle.getName();
			if(name.matches("[0-9]{10}.jpg")){
				result.add(name.substring(0,10));
			}
		}
		return result;
	}

	public static void copyIO(InputStream in, OutputStream out)
			throws IOException {
		byte[] buf = new byte[CHUNK_SIZE];
		/**
		 * 从输入流读取内容并写入到另外一个流的典型方法
		 */
		int len = in.read(buf);
		while (len != -1) {
			out.write(buf, 0, len);
			len = in.read(buf);
		}
	}

	public static void copyFile(String fsrc, String fdest) throws IOException {
		InputStream in = null;
		OutputStream out = null;
		try {
			in = new FileInputStream(fsrc);
			out = new FileOutputStream(fdest, true);
			copyIO(in, out);
		} finally {
			close(in);
			close(out);
		}
	}

	public static void close(Closeable inout) {
		if (inout != null) {
			try {
				inout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}




	/**
	 *
	 * @param studentListFile  存放学生名单的文件名
	 * @param srcDir 图片存放的目录（不会包含子目录）
	 */
    //返回没有上交学生照片的ID
	public Set<String> copyToTargetDirAndReturnNoExist(String studentListFile,String srcDir,String target) throws Exception {
		List<String[]> nameList=getNameList(studentListFile);
		List<String> fileIdList=getValidFileIdList(srcDir);
		Set<String> noExistIdSet=new HashSet<>();

		for(String[] stu:nameList){
			File targetDir=new File(target,stu[2]);
			if(!targetDir.exists())
				targetDir.mkdirs();
		}
		for(int i=0;i<nameList.size();i++){
			String id=nameList.get(i)[0];
			String name=nameList.get(i)[1];
			String classNo=nameList.get(i)[2];

			if(!fileIdList.contains(id)){
				noExistIdSet.add(id);
			}else{
				String srcPath=srcDir+id+".jpg";
				String targetPath=target+classNo+"/"+id+"_"+name+".jpg";
				copyFile(srcPath,targetPath);
			}
		}
		return noExistIdSet;

	}
 

}
