package com.huawei.classroom.student.h04;

public class Triangle {
    private int A,B,C;
    public void setA(int i){
        this.A=i;
    }
    public void setB(int i){
        this.B=i;
    }

    public void setC(int c) {
        C = c;
    }
    public double getArea(){
        return 0.25*Math.sqrt((A+B+C)*(B+C-A)*(A+C-B)*(A+B-C));
    }
}
