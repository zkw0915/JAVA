package com.huawei.classroom.student.h04;

public class MyStack {
     private int size;
     private int count;
     private int[] stack;

     public MyStack(int n){
         this.stack=new int[n];
         this.count=0;
         this.size=size=n;
     }
     public boolean isEmpty(){
         if(count==0)
             return true;
         else
             return false;
     }
     public boolean isFull(){
         if(count==size){
             return true;
         }
         else
             return false;
     }

     public void push(int i){
         stack[count]=i;
         count++;
     }
     public int pop(){
         count--;
         return stack[count];
     }
}
