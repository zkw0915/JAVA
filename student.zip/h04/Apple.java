package com.huawei.classroom.student.h04;

public class Apple {
         private String color;
         private int size;

         public Apple(){
              color="red";
         }
         public Apple(int size,String color)
         {
             this.size=size;
             this.color=color;
         }
    public int getSize() {
        return this.size;
    }

    public String getColor() {
        return this.color;
    }
}
// TODO Auto-generated method stub
