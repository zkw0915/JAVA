package com.huawei.classroom.student.h19.q03;

import java.util.Arrays;

public class ArrayUtil {
    public ArrayUtil(){
    }
    public int getMin(int[] case1) {
        Arrays.sort(case1);
        return case1[0];
    }
}
