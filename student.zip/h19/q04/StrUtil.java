package com.huawei.classroom.student.h19.q04;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class StrUtil {
    public String removeDulpicatedChar(String aabbac) {
        List<String> data=new ArrayList<String>();
        for(int i=0;i<aabbac.length();i++){
            String s=aabbac.substring(i,i+1);
            if(!data.contains(s)){
                data.add(s);
            }
        }
        String result="";
        for(String s:data){
            result+=s;
        }
        //System.out.println(result);
        return result;
    }
}
