package com.huawei.classroom.student.h19.q02;

public class Person {
    private String name;

    public Person(){
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
