package com.huawei.classroom.student.h07;

public enum EnumObjectType {
	barrack,rifleSoldier,RPGSoldier,dog,
}
