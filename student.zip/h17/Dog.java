package com.huawei.classroom.student.h17;

public class Dog extends GameObject {

	public Dog( GameObjectVo vo) {
		super(vo);
		//super(  Param.DOG_HEALTH,Param.DOG_STRENGTH);
		// TODO Auto-generated constructor stub
	}


}
