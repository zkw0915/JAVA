package com.huawei.classroom.student.h17;

public abstract class Soldier extends GameObject {
 
	
	public Soldier( GameObjectVo vo) {
		super(  vo); 
		// TODO Auto-generated constructor stub
	} 
 

}
