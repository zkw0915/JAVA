package com.huawei.classroom.student.h17;

public class Building extends GameObject {

	public Building( GameObjectVo vo) {
		super(   vo);
		// TODO Auto-generated constructor stub
	}

	 

}
