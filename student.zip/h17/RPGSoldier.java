package com.huawei.classroom.student.h17;

public class RPGSoldier extends Soldier {

 

	public RPGSoldier( GameObjectVo vo ) {
		super(vo);
		//super( Param.SOLDIER_HEALTH,Param.SOLDIER_RPG_STRENGTH );
		// TODO Auto-generated constructor stub
	}

}
