package com.huawei.classroom.student.h17;

public enum EnumObjectType {
	base,heavyTank,mediumTank,rifleSoldier,RPGSoldier,dog,barrack,warFactory
}
