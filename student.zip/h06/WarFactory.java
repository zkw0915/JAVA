package com.huawei.classroom.student.h06;

public class WarFactory extends GameBase{
    public WarFactory(int x,int y){
        super(x,y);
        super.setHealth(100);
        super.setAttack(0);
    }

    public Tank building(EnumObjectType target){
        switch(target){
            case mediumTank:
                return new MediumTank(getX(),getY());
            case heavyTank:
                return new HeavyTank(getX(),getY());
            default:
                return null;
        }
    }

}
