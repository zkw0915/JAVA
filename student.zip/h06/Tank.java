package com.huawei.classroom.student.h06;

public class Tank extends Unit{

}
