package com.huawei.classroom.student.h06;

public class Dog extends Unit{
    public Dog(int x,int y){
        super.setLocation(x,y);
        super.setHealth(50);
        super.setAttack(5);
        super.range(5);
    }

    public void attack(Soldier soldier) {
        if(soldier.getHealth()<=0)
            return;
        int dx = this.getX() - soldier.getX();
        int dy = this.getY() - soldier.getY();
        double dis = Math.pow(dx * dx + dy * dy, 0.5);
        if (this.getM() < dis) {
            return;
        }
        soldier.setHealth(0);
        soldier.count_live--;
        soldier.count_dead++;
    }

}
