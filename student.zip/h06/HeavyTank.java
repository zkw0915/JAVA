package com.huawei.classroom.student.h06;

public class HeavyTank extends Tank{
    public HeavyTank(int x,int y){
        super.setHealth(200);
        super.setAttack(20);
        super.setLocation(x,y);
        super.range(10);
    }


}
