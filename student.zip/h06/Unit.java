package com.huawei.classroom.student.h06;

public class Unit {
    private int health,attack,x,y,m;

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth() {
        if(this.health>0)
            return this.health;
        else
            return -1;
    }

    public boolean isDestroyed(){return this.health<=0;}

    public void beAttacked(int a) {
        this.health -= a;
    }

    public void attack(Unit target) {
        if (target.isDestroyed())
            return;
        int a1=target.getX();
        int b1=target.getY();
        int a2=this.getX();
        int b2=this.getY();
        int a=Math.abs(a1-a2);
        int b=Math.abs(b1-b2);
        double c=Math.sqrt(a*a+b*b);
        if(c<=this.m)
            target.beAttacked(this.attack);
    }

    public void setLocation(int x,int y){
        this.x=x;
        this.y=y;
    }

    public int getX() {
        return x;
    }
    public int getY(){
        return y;
    }
    public int getM() { return m; }
    public void range(int m){
        this.m=m;
    }

    public void move(int i, int i1) {
        x+=i;
        y+=i1;
    }
}
