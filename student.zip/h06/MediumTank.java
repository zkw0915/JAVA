package com.huawei.classroom.student.h06;

public class MediumTank extends Tank{
    public MediumTank(int x,int y){
        super.setAttack(10);
        super.setHealth(100);
        super.setLocation(x,y);
        super.range(10);
    }

}
