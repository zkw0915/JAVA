package com.huawei.classroom.student.h06;

public class RPGSoldier extends Soldier {
    public RPGSoldier(int x,int y){
        super.setHealth(50);
        super.setAttack(10);
        super.setLocation(x,y);
        super.range(10);
    }

    public void attack(Dog dog) {
        if(dog.getHealth()<=0)
            return;
        int dx = this.getX() - dog.getX();
        int dy = this.getY() - dog.getY();
        double dis = Math.pow(dx * dx + dy * dy, 0.5);
        if (this.getM() < dis) {
            return;
        }
        dog.setHealth(0);
    }

}
