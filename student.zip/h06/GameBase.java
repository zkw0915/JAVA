package com.huawei.classroom.student.h06;

public class GameBase extends Unit {
    public GameBase(int x,int y){
        super.setHealth(500);
        super.setAttack(0);
        super.setLocation(x,y);
    }

    public static GameBase createGameBase(int i, int i1) {
        return new GameBase(i,i1);
    }

    public GameBase building(EnumObjectType target,int x,int y){
        switch(target)
        {
            case barrack:
                return new Barrack(x,y);
            case warFactory:
                return new WarFactory(x,y);
            default:
                return null;
        }
    }
}
