package com.huawei.classroom.student.h06;

public class RifleSoldier extends Soldier{
    public RifleSoldier(int x,int y){
        super.setLocation(x,y);
        super.setHealth(50);
        super.setAttack(5);
        super.range(5);
    }

    public void attack(Dog target) {
        target.setHealth(0);
        super.attack(target);
    }
}
