package com.huawei.classroom.student.h06;

public class Soldier extends Unit{
    public static int count_live=0,count_dead=0;

    public Soldier(){ count_live++; }



    public static int getLivingSoldierCount() {
        return count_live;
    }

    public static int getDeadedSoldierCount() {
        return count_dead;
    }

}
