package com.huawei.classroom.student.h06;

public class Barrack extends GameBase{
    public Barrack(int x,int y){
        super(x,y);
        super.setHealth(100);
        super.setAttack(0);
    }

    public Object traing(EnumObjectType target) {
        switch (target){
            case dog:
                return new Dog(getX(),getY());
            case RPGSoldier:
                return new RPGSoldier(getX(),getY());
            case rifleSoldier:
                return new RifleSoldier(getX(),getY());
            default:
                return null;

        }
    }
}
