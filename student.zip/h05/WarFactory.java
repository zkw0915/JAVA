package com.huawei.classroom.student.h05;

public class WarFactory extends Unit{
    public WarFactory(){
        super.setHealth(100);
        super.setAttack(0);
    }

    public Tank building(EnumObjectType target){
        switch(target){
            case mediumTank:
                return new MediumTank();
            case heavyTank:
                return new HeavyTank();
            default:
                return null;
        }
    }

}
