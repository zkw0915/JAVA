package com.huawei.classroom.student.h05;

public class Unit {
    private int health,attack;

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth() {
        if(this.health>0)
            return this.health;
        else
            return -1;
    }

    public boolean isDestroyed(){return this.health<=0;}

    public void beAttacked(int a) {
        this.health -= a;
    }

    public void attack(Unit target) {
        target.beAttacked(this.attack);
    }


}
