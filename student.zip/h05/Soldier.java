package com.huawei.classroom.student.h05;

public class Soldier extends Unit{
    private static int count_live=0,count_dead=0;

    public Soldier(){ count_live++; }

    @Override
    public void beAttacked(int a) {
        super.beAttacked(a);

        if(super.isDestroyed()){
            count_live--;
            count_dead++;
        }
    }

    public static int getLivingSoldierCount() {
        return count_live;
    }

    public static int getDeadedSoldierCount() {
        return count_dead;
    }

}
