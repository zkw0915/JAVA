package com.huawei.classroom.student.h05;

public class Barrack extends Unit{
    public Barrack(){
        super.setHealth(100);
        super.setAttack(0);
    }

    public Object traing(EnumObjectType target) {
        switch (target){
            case dog:
                return new Dog();
            case RPGSoldier:
                return new RPGSoldier();
            case rifleSoldier:
                return new RifleSoldier();
            default:
                return null;

        }
    }
}
