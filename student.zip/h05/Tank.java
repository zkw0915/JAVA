package com.huawei.classroom.student.h05;

public class Tank extends Unit{

}
