package com.huawei.classroom.student.h05;

public class MediumTank extends Tank{
    public MediumTank(){
        super.setAttack(10);
        super.setHealth(100);
    }

}
