package com.huawei.classroom.student.h05;

public class Dog extends Unit{
    public Dog(){
        super.setHealth(50);
        super.setAttack(5);
    }

    public void attack(Soldier target) {
        target.setHealth(0);
        super.attack(target);
    }

}
