package com.huawei.classroom.student.h05;

public class RPGSoldier extends Soldier {
    public RPGSoldier(){
        super.setHealth(50);
        super.setAttack(0);
    }

}
