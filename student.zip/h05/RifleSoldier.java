package com.huawei.classroom.student.h05;

public class RifleSoldier extends Soldier{
    public RifleSoldier(){
        super.setHealth(50);
        super.setAttack(5);
    }

    public void attack(Dog target) {
        target.setHealth(0);
        super.attack(target);
    }
}
