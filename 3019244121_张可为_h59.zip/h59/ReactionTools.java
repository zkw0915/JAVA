package com.huawei.classroom.student.h59;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ReactionTools {

	/**
	 * 根据reactionFile给出的一系列反应， 判断一个体系中根据init物质，判断出最后可能都存在什么物质
	 * @param reactionFile 体系中初始反应物
	 * @param initComponents 体系中初始反应物
	 * @return 最后体系中存在的全部物质
	 */
	public Set<String> findAllComponents(String reactionFile,Set<String> initComponents){
		List<Reaction> reactions=readLines(reactionFile);
		Set<String> result=new HashSet<>(initComponents);
		int newAddCount=initComponents.size();
		while (newAddCount != 0) {
			newAddCount = 0;
			for (Reaction reaction : reactions) {
				// contain or not contain, that is a question
				if (result.containsAll(reaction.getReactant()) && !result.containsAll(reaction.getProduct())) {
					result.addAll(reaction.getProduct());
					newAddCount++;
				} else if (result.containsAll(reaction.getProduct()) && !result.containsAll(reaction.getReactant())) {
					result.addAll(reaction.getReactant());
					newAddCount++;
				}
			}
		}
		return result;
	}

	private List<Reaction> readLines(String filename) {
		String line;
		Reader reader=null;
		List<Reaction> result=new ArrayList<>();
		try{
			reader=new FileReader(filename);//reader读取filename中的内容
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		if(reader==null){
			return null;
		}

		LineNumberReader lineNumberReader=new LineNumberReader(reader);//按行读取reader

		try{
			while (true){
			  	line=lineNumberReader.readLine();
			  	if(line==null)
			  		break;
			  	if(line.trim().length()==0||line.startsWith("#"))
			  		continue;
			  	String[] reaction=line.split("=");//根据=将化学式分成两部分
				String left=reaction[0];
				String right=reaction[1];
				String[] lefts=left.split("\\ \\+\\ ");//左侧以" + "分隔
				Set<String> leftSet=new HashSet<>();
				for(String s:lefts){
					leftSet.add(s.trim());
				}
				String[] rights=right.split("\\ \\+\\ ");
				Set<String> rightSet=new HashSet<>();
				for(String s:rights){
					rightSet.add(s.trim());
				}
				result.add(new Reaction(leftSet,rightSet));
			  }
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;//这里的result是对，例如（HCL，H+,CL-）
	}
}

